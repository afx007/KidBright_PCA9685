Blockly.Msg.SPD="SPEED";
Blockly.Msg.SPDINFO="SPEED 0% - 100%";
Blockly.Msg.MyURL="https://github.com/afx007/KidBright_PCA9685";