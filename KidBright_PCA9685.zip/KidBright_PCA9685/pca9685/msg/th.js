//Blockly.Msg.MaxPWMPort="จำนวน PWM ที่ใช้";
//Blockly.Msg.PWM = "ตั้งค่า PWM";
Blockly.Msg.SPD="ความเร็ว";
Blockly.Msg.SPDINFO="ความเร็ว 0% - 100%";
Blockly.Msg.MyURL="https://github.com/afx007/KidBright_PCA9685";